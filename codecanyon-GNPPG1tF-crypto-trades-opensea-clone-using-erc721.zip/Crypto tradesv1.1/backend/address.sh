#!/bin/bash

export WEB3_RPC_URL=WEB3_RPC_URL=https://rinkeby.infura.io/v3/64fa77a39b9a4c31b186fb2148edff70

web3 account create
